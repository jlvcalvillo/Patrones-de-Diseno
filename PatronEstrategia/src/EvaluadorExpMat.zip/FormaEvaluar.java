package EvaluadorExpMat;

/**
 *
 * @author JLuis
 */
public interface FormaEvaluar {
    public double evaluacion (ExpresionMatComp emc);
}
