package EvaluadorExpMat;

/**
 *
 * @author JLuis
 */
public class SinEvaluacion implements FormaEvaluar{

    @Override
    public double evaluacion(ExpresionMatComp emc) {
        return 0.0;
    }
    
}
