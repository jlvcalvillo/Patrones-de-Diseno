package EvaluadorExpMat;

/**
 *
 * @author JLuis
 */
public interface FormaSumaResta {
    public ExpresionMatComp suma(ExpresionMatComp val1, ExpresionMatComp val2);
    public ExpresionMatComp resta(ExpresionMatComp val1, ExpresionMatComp val2);
}
